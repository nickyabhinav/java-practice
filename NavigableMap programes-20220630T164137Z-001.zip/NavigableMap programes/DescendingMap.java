/*The java.util.NavigableMap interface, a new addition to Java 6, inherits SortedMap to add navigation methods that allows for key/value pair searching.

The java.util.TreeMap class in Java 6 implements NavigableMap.*/


import java.util.NavigableMap;
import java.util.TreeMap;
import java.util.Map.Entry;

public class DescendingMap 
{
  public static void main(String[] args) 
{
    NavigableMap<Integer, String> map = new TreeMap<Integer, String>();
    map.put(2, "two");
    map.put(1, "one");
    map.put(3, "three");
    System.out.println("Original map: " + map + "\n");
NavigableMap reverse = map.descendingMap();
System.out.println("Descending map: " + reverse + "\n");

    
  }
}